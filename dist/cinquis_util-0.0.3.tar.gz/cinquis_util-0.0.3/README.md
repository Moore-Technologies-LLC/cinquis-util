# cinquis-util
cinquis utilities repo
## Patch History
### 0.0.1 
untested build
### 0.0.2
cleand up code with pylint
### 0.0.3
renamed cinquis-util to cinquis_util due to package name requirements
